import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const interestLeads = sqliteTable("interest_leads", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  profile: text("profile", { enum: ["paciente", "profissional"] }).notNull(),
  name: text("name").notNull(),
  contact: text("contact").notNull(),
  city: text("city"),
  state: text("state"),
  specialty: text("specialty"),
  profession: text("profession"),
  councilRegistration: text("council_registration"),
  consentAt: text("consent_at").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
