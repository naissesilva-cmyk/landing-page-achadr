import { getDb } from "../../../db";
import { interestLeads } from "../../../db/schema";

type LeadPayload = {
  profile?: string;
  name?: string;
  contact?: string;
  city?: string;
  state?: string;
  specialty?: string;
  profession?: string;
  councilRegistration?: string;
  consent?: boolean;
  website?: string;
};

const clean = (value: unknown, maxLength = 180) =>
  typeof value === "string" ? value.trim().slice(0, maxLength) : "";

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as LeadPayload;
    const profile = clean(payload.profile, 20);
    const name = clean(payload.name, 120);
    const contact = clean(payload.contact, 180);
    const city = clean(payload.city, 120);
    const state = clean(payload.state, 2).toUpperCase();
    const specialty = clean(payload.specialty, 140);
    const profession = clean(payload.profession, 140);
    const councilRegistration = clean(payload.councilRegistration, 80);

    if (payload.website) {
      return Response.json({ success: true }, { status: 201 });
    }

    if (profile !== "profissional") {
      return Response.json({ error: "Este cadastro é exclusivo para profissionais de saúde." }, { status: 400 });
    }

    if (name.length < 2 || contact.length < 5) {
      return Response.json({ error: "Informe seu nome e um contato válido." }, { status: 400 });
    }

    if (!profession || !specialty) {
      return Response.json({ error: "Informe sua profissão e especialidade." }, { status: 400 });
    }

    if (!councilRegistration) {
      return Response.json({ error: "Informe seu registro no conselho profissional." }, { status: 400 });
    }

    if (payload.consent !== true) {
      return Response.json({ error: "É necessário aceitar a Política de Privacidade." }, { status: 400 });
    }

    const db = getDb();
    await db.insert(interestLeads).values({
      profile,
      name,
      contact,
      city: city || null,
      state: state || null,
      specialty: specialty || null,
      profession: profession || null,
      councilRegistration,
      consentAt: new Date().toISOString(),
    });

    return Response.json({ success: true }, { status: 201 });
  } catch (error) {
    console.error("Failed to save interest lead", error);
    return Response.json(
      { error: "Não foi possível concluir o cadastro agora. Tente novamente em instantes." },
      { status: 500 },
    );
  }
}
