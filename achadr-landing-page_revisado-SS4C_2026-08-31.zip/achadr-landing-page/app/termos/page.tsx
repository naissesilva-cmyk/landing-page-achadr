import type { Metadata } from "next";
import Link from "next/link";
import LegalPageLayout from "../components/LegalPageLayout";

export const metadata: Metadata = {
  title: "Termos de Uso | achaDR",
  description: "Termos de Uso da achaDR e condições de utilização da plataforma.",
  alternates: { canonical: "/termos" },
};

export default function TermsPage() {
  return (
    <LegalPageLayout
      title="Termos de Uso"
      introduction="Estes Termos apresentam as condições do cadastro antecipado profissional e da atuação pela achaDR."
    >
      <h2>1. O que é a achaDR</h2>
      <p>
        A achaDR é uma plataforma de intermediação que conecta pacientes a profissionais de saúde para atendimentos por vídeo. A achaDR não presta serviços de saúde: o atendimento, o diagnóstico, a prescrição e qualquer conduta são de responsabilidade do profissional.
      </p>
      <p>
        O profissional atua de forma autônoma e independente, sem vínculo empregatício, societário, de subordinação, exclusividade ou representação com a achaDR. A conexão depende da proposta do paciente e da decisão do profissional, que pode aceitar ou recusar a solicitação.
      </p>

      <h2>2. Cadastro e elegibilidade</h2>
      <p>
        Para utilizar a plataforma, o usuário deve ser maior de 18 anos ou estar representado por responsável legal e fornecer informações verdadeiras. O profissional declara possuir registro ativo e regular no respectivo conselho de classe e habilitação para a modalidade de telessaúde. Médicos que se apresentem como especialistas deverão possuir o respectivo Registro de Qualificação de Especialista (RQE), conforme as normas aplicáveis.
      </p>
      <p>
        O cadastro antecipado realizado nesta página registra os dados do profissional para a fase de lançamento. Ele não libera acesso imediato, não garante solicitações ou contratação de atendimentos e não gera obrigação de contato individual pela achaDR.
      </p>
      <p>
        Para o profissional, a taxa padrão de R$ 50 está relacionada à ativação da conta de pagamentos usada para receber os repasses. Na condição de pré-lançamento apresentada nesta página, o profissional registra o interesse na isenção desse valor e na taxa de uso da plataforma reduzida para 10% sobre cada atendimento realizado, em vez dos 20% padrão. A taxa de 10% permanecerá válida durante toda a permanência do profissional na achaDR, observados os critérios de elegibilidade e a manutenção da mesma conta.
      </p>

      <h2>3. Como funciona</h2>
      <p>
        O paciente informa a especialidade e o valor que deseja propor. Profissionais aptos podem avaliar a solicitação e decidir se aceitam. Quando houver um ou mais aceites, o paciente poderá considerar os perfis e as condições disponíveis e escolher com quem deseja avançar. Após a escolha e a confirmação, o atendimento segue conforme as condições apresentadas na plataforma.
      </p>

      <h2>4. Responsabilidades do profissional</h2>
      <p>
        São de responsabilidade do profissional a regularidade do registro, o cumprimento das normas do respectivo conselho e da legislação aplicável à telessaúde, o consentimento do paciente, o prontuário, a prescrição, o sigilo e a avaliação sobre a adequação do atendimento a distância.
      </p>

      <h2>5. Responsabilidades do paciente</h2>
      <p>
        O paciente deve fornecer informações verdadeiras e utilizar o serviço de forma adequada. A teleconsulta não substitui pronto-atendimento em emergências. Em situações de urgência ou emergência, procure um serviço presencial ou ligue para o SAMU pelo número 192.
      </p>

      <h2>6. Pagamentos</h2>
      <p>
        O pagamento da consulta é realizado pela plataforma e processado pelo parceiro de pagamentos. A achaDR desconta do profissional a taxa de uso aplicável e repassa o valor líquido do atendimento para a respectiva conta de pagamentos.
      </p>
      <p>
        A taxa padrão da plataforma para o profissional será de 20% sobre cada atendimento realizado. Profissionais elegíveis à condição de pré-lançamento terão a taxa reduzida para 10% durante toda a permanência na achaDR. O valor da consulta, o desconto, o repasse, eventuais reembolsos e as demais condições financeiras serão apresentados antes da confirmação.
      </p>

      <h2>7. Limitação de responsabilidade</h2>
      <p>
        Como plataforma de intermediação, a achaDR não responde pelas condutas, diagnósticos, prescrições ou resultados do atendimento, que permanecem sob responsabilidade do profissional. A achaDR adota medidas para manter a disponibilidade da plataforma, sem garantir funcionamento ininterrupto.
      </p>

      <h2>8. Privacidade e dados pessoais</h2>
      <p>
        O tratamento de dados pessoais, incluindo dados sensíveis de saúde quando aplicável, segue a <Link href="/privacidade">Política de Privacidade</Link> e a legislação vigente.
      </p>

      <h2>9. Alterações</h2>
      <p>
        Estes Termos poderão ser atualizados para refletir mudanças na plataforma, na operação ou na legislação. A versão vigente ficará disponível neste endereço.
      </p>

      <div className="legal-contact">
        <strong>Antes de continuar</strong>
        <p>Leia também a <Link href="/privacidade">Política de Privacidade</Link>. Ao enviar o cadastro antecipado, criar uma conta ou utilizar a plataforma, você declara que leu e concorda com os documentos aplicáveis.</p>
      </div>
    </LegalPageLayout>
  );
}
