import type { Metadata } from "next";
import "./globals.css";

const title = "achaDR para profissionais — Novas consultas, sua decisão";
const description = "Receba novas oportunidades de atendimento online, avalie cada proposta e decida quando e por quanto atender.";

export const metadata: Metadata = {
  metadataBase: new URL("https://www.achadr.com.br"),
  title,
  description,
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: "/",
    siteName: "achaDR",
    title,
    description,
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "achaDR para profissionais de saúde. Novas consultas, sua decisão.",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title,
    description,
    images: ["/og.png"],
  },
  icons: {
    icon: "/logo-achadr.png",
    shortcut: "/logo-achadr.png",
    apple: "/logo-achadr.png",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <head>
        {/* Inter, os mesmos pesos do achadr.com.br. Sem isto o font-family cai no
            fallback do sistema e a página inteira muda de desenho — foi o que
            mais destoava do site publicado. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font --
            A regra mira o roteador antigo (pages/_document). Aqui o link está no
            layout RAIZ do App Router, então vale para todas as páginas. Mantido
            como <link> de propósito: é exatamente o que achadr.com.br carrega,
            e divergir no carregamento da fonte é divergir no desenho. */}
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
