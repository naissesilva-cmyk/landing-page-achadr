import Image from "next/image";
import InterestForm from "./components/InterestForm";
import { Icone } from "./components/Icone";

const benefits = [
  {
    title: "Demanda de quem já procura sua especialidade",
    description: "Receba solicitações alinhadas à sua área de atuação sem depender apenas da captação própria.",
  },
  {
    title: "Valor e condições antes do compromisso",
    description: "Veja o que foi proposto e aceite somente quando o atendimento fizer sentido para você.",
  },
  {
    title: "Um canal complementar, sem exclusividade",
    description: "Concilie a achaDR com consultório, particular, convênios e sua rotina atual.",
  },
] as const;

const steps = [
  { number: "01", title: "Cadastre", description: "Informe sua profissão, especialidade e registro." },
  { number: "02", title: "Disponibilize", description: "Defina os horários em que deseja atender online." },
  { number: "03", title: "Receba", description: "Veja solicitações compatíveis com sua área de atuação." },
  { number: "04", title: "Decida", description: "Analise necessidade, valor e horário antes de aceitar." },
  { number: "05", title: "Atenda", description: "Realize a consulta por vídeo e receba o repasse." },
] as const;

const assurances = [
  { title: "R$ 50 por R$ 0", text: "Isenção da taxa de ativação no pré-lançamento." },
  { title: "10% para sempre", text: "Em vez da taxa padrão de 20% sobre cada atendimento." },
  { title: "Sem exclusividade", text: "Use a achaDR junto às suas outras formas de atendimento." },
  { title: "Você decide", text: "Nenhuma proposta é aceita automaticamente." },
] as const;

const faqs = [
  {
    question: "Sou obrigado a aceitar uma proposta?",
    answer: "Não. Você analisa cada solicitação e decide se ela faz sentido para sua atuação, disponibilidade e critérios profissionais.",
  },
  {
    question: "Quem pode se cadastrar?",
    answer: "Profissionais de saúde habilitados nas categorias disponíveis na achaDR e com registro ativo e regular no respectivo conselho profissional.",
  },
  {
    question: "A achaDR garante agenda cheia?",
    answer: "Não. A achaDR cria um canal complementar de demanda. A quantidade de solicitações depende de fatores como especialidade, disponibilidade e procura.",
  },
  {
    question: "Como funciona a inscrição profissional gratuita?",
    answer: "A inscrição profissional terá uma taxa padrão de R$ 50. Quem concluir o pré-cadastro e atender aos critérios da campanha terá isenção desse valor.",
  },
  {
    question: "Qual é a condição especial da taxa de parceria?",
    answer: "A taxa padrão será de 20% sobre cada atendimento realizado. Para profissionais elegíveis ao pré-lançamento, ela será reduzida pela metade, para 10%, durante toda a permanência na achaDR.",
  },
  {
    question: "Como recebo pelos atendimentos?",
    answer: "O pagamento da consulta é feito pela plataforma. A taxa aplicável é descontada e o valor líquido é repassado para sua conta de pagamentos.",
  },
  {
    question: "Eu escolho quando atender?",
    answer: "Sim. Você informa sua disponibilidade e aceita apenas os atendimentos compatíveis com sua rotina.",
  },
] as const;

export default function Home() {
  return (
    <div className="profile-page profile-profissional">
      <header className="site-header">
        <div className="container header-inner">
          <a className="brand" href="#inicio" aria-label="Ir para o início">
            <Image src="/logo-achadr.png" alt="Logotipo da achaDR" width={48} height={48} priority unoptimized />
            <span className="brand-copy">
              <strong>acha<span>DR</span></strong>
              <small>Saúde no seu tempo, no seu preço.</small>
            </span>
          </a>

          <nav className="main-nav" aria-label="Navegação principal">
            <a href="#beneficios">Benefícios</a>
            <a href="#como-funciona">Como funciona</a>
            <a href="#oferta">Condição de lançamento</a>
          </nav>

          <a className="button button-small button-primary header-cta" href="#cadastro">Quero me cadastrar</a>
        </div>
      </header>

      <main>
        <section className="hero" id="inicio">
          <div className="container hero-grid">
            <div className="hero-content">
              <span className="eyebrow eyebrow-light">Pré-lançamento para profissionais de saúde</span>
              <h1>Transforme horários disponíveis em novas consultas.<span>Você decide quando e por quanto atender.</span></h1>
              <p className="hero-description">
                A achaDR aproxima você de pessoas que já procuram sua especialidade. Cada solicitação chega com necessidade, horário e valor proposto para você analisar antes de aceitar.
              </p>

              <div className="hero-actions">
                <a className="button button-coral" href="#cadastro">Quero minha inscrição gratuita</a>
                <a className="button button-outline-light" href="#como-funciona">Entender como funciona</a>
              </div>

              <p className="launch-note"><span aria-hidden="true"></span>Inscrição profissional gratuita · condição exclusiva na taxa de parceria.</p>
            </div>

            <div className="hero-visual" aria-label="Exemplo ilustrativo de uma proposta recebida por um profissional de saúde">
              <div className="connection-line connection-line-one" aria-hidden="true"></div>
              <div className="connection-line connection-line-two" aria-hidden="true"></div>
              <div className="orbit-dot orbit-dot-coral" aria-hidden="true"></div>
              <div className="orbit-dot orbit-dot-teal" aria-hidden="true"></div>

              <div className="interface-card">
                <div className="interface-topbar">
                  <div className="interface-brand">
                    <Image src="/logo-achadr.png" alt="" width={34} height={34} unoptimized />
                    <span>acha<strong>DR</strong></span>
                  </div>
                  <span className="status-pill">Nova solicitação</span>
                </div>

                <div className="interface-body">
                  <span className="interface-label">Especialidade</span>
                  <strong className="interface-specialty">Psicologia · vídeo</strong>
                  <div className="proposal-box">
                    <div><span>Valor proposto</span><strong>R$ 80,00</strong></div>
                    <span className="proposal-icon" aria-hidden="true"><Icone nome="arrow-up-right" size={18} /></span>
                  </div>
                  <div className="decision-box">
                    <span>A decisão é sua</span>
                    <div className="decision-actions" aria-hidden="true">
                      <span className="decision-secondary">Recusar</span>
                      <span className="decision-primary">Aceitar</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="floating-message floating-message-top">
                <span className="message-icon"><Icone nome="check" size={14} /></span>
                <div><small>Disponibilidade</small><strong>Você define</strong></div>
              </div>
              <div className="floating-message floating-message-bottom">
                <span className="message-dot"></span>
                <div><small>Cada proposta</small><strong>Você avalia</strong></div>
              </div>
            </div>
          </div>
        </section>

        <section className="context-section" aria-labelledby="context-title">
          <div className="container context-grid">
            <div>
              <span className="eyebrow">Renda complementar sem agenda imposta</span>
              <h2 id="context-title">Mais oportunidades sem abrir mão do seu valor.</h2>
            </div>
            <div className="context-side">
              <p>
                Em modelos com remuneração previamente definida, o valor chega pronto. Na achaDR, a proposta chega antes do compromisso: você avalia a demanda, o horário e o valor e decide se quer atender.
              </p>
              <div className="context-tags" aria-label="Diferenciais para o profissional">
                <span>Demanda compatível</span>
                <span>Valor visível</span>
                <span>Aceite livre</span>
                <span>Sem exclusividade</span>
              </div>
            </div>
          </div>
        </section>

        <section className="benefits-section" id="beneficios" aria-labelledby="benefits-title">
          <div className="container">
            <div className="section-heading">
              <span className="eyebrow eyebrow-light">O que muda para você</span>
              <h2 id="benefits-title">Uma nova fonte de consultas, com decisão profissional em cada etapa.</h2>
              <p>A achaDR complementa sua atuação atual sem prometer agenda cheia e sem retirar seu controle sobre preço e disponibilidade.</p>
            </div>

            <div className="benefits-grid">
              {benefits.map((benefit, index) => (
                <article className="benefit-card" key={benefit.title}>
                  <span>0{index + 1}</span>
                  <h3>{benefit.title}</h3>
                  <p>{benefit.description}</p>
                </article>
              ))}
            </div>

            <div className="conversion-callout" id="oferta">
              <div>
                <span className="eyebrow eyebrow-light">Condição de pré-lançamento</span>
                <h2>Comece sem taxa de inscrição e mantenha uma condição especial para sempre.</h2>
                <p>
                  No pré-lançamento, a taxa de R$ 50 para ativação da conta profissional será totalmente isenta. Além disso, a taxa de parceria será reduzida de 20% para 10% sobre cada atendimento realizado, durante toda a sua permanência na achaDR. Você só paga quando atender.
                </p>
              </div>
              <a className="button button-coral" href="#cadastro">Quero esta condição</a>
            </div>
          </div>
        </section>

        <section className="steps-section" id="como-funciona">
          <div className="container">
            <div className="section-heading centered">
              <span className="eyebrow">Como funciona</span>
              <h2>Do cadastro ao primeiro atendimento.</h2>
              <p>Um fluxo direto para você receber oportunidades e decidir sem obrigação de aceite.</p>
            </div>

            <ol className="steps-grid">
              {steps.map((step) => (
                <li className="step-card" key={step.number}>
                  <span className="step-number">{step.number}</span>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="interest-section" id="cadastro" aria-labelledby="interest-title">
          <div className="container interest-grid">
            <div className="interest-copy">
              <span className="eyebrow">Cadastro antecipado profissional</span>
              <h2 id="interest-title">Faça sua inscrição profissional gratuitamente.</h2>
              <p>Registre seus dados para garantir a isenção dos R$ 50 e a taxa reduzida sobre os atendimentos. O pré-cadastro não gera cobrança nem obriga você a aceitar propostas.</p>

              <div className="interest-assurances" aria-label="Benefícios do cadastro antecipado">
                {assurances.map((item) => (
                  <div key={item.title}>
                    <Icone nome="check" size={16} />
                    <p><strong>{item.title}</strong><small>{item.text}</small></p>
                  </div>
                ))}
              </div>

              <div className="legal-shortcuts">
                <a href="/privacidade">Política de Privacidade <Icone nome="arrow-up-right" size={14} /></a>
                <a href="/termos">Termos de Uso <Icone nome="arrow-up-right" size={14} /></a>
              </div>
            </div>

            <InterestForm />
          </div>
        </section>

        <section className="faq-section" id="duvidas">
          <div className="container faq-grid">
            <div className="faq-intro">
              <span className="eyebrow">Dúvidas frequentes</span>
              <h2>Antes de se cadastrar.</h2>
              <p>Informações objetivas sobre a condição de pré-lançamento para profissionais de saúde.</p>
            </div>

            <div className="faq-list">
              {faqs.map((faq) => (
                <details key={faq.question}>
                  <summary>{faq.question}<Icone nome="plus" size={18} /></summary>
                  <p>{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <a className="brand brand-footer" href="#inicio" aria-label="Voltar ao início">
            <Image className="footer-logo" src="/logo-achadr.png" alt="Logotipo da achaDR" width={52} height={52} unoptimized />
            <span className="brand-copy"><strong>acha<span>DR</span></strong><small>Saúde no seu tempo, no seu preço.</small></span>
          </a>
          <div className="footer-links">
            <a href="/termos">Termos de Uso</a>
            <a href="/privacidade">Política de Privacidade</a>
            <a href="#cadastro">Fazer cadastro</a>
          </div>
          <p className="footer-disclaimer">A achaDR conecta solicitações de atendimento a profissionais de saúde habilitados. Cada profissional decide quais propostas deseja aceitar.</p>
        </div>
      </footer>
    </div>
  );
}
