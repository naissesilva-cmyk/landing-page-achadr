import Image from "next/image";
import Link from "next/link";
import { ReactNode } from "react";

type LegalPageLayoutProps = {
  title: string;
  introduction: string;
  children: ReactNode;
};

export default function LegalPageLayout({ title, introduction, children }: LegalPageLayoutProps) {
  return (
    <>
      <header className="site-header legal-header">
        <div className="container header-inner">
          <Link className="brand" href="/" aria-label="Voltar para a página inicial da achaDR">
            <Image src="/logo-achadr.png" alt="Logotipo da achaDR" width={48} height={48} priority unoptimized />
            <span className="brand-copy"><strong>acha<span>DR</span></strong><small>Saúde no seu tempo, no seu preço.</small></span>
          </Link>
          <Link className="legal-back-link" href="/">Voltar para a página inicial</Link>
        </div>
      </header>

      <main className="legal-page">
        <section className="legal-hero">
          <div className="container legal-hero-inner">
            <span className="eyebrow eyebrow-light">Documento legal</span>
            <h1>{title}</h1>
            <p>{introduction}</p>
          </div>
        </section>

        <article className="container legal-content">
          <p className="legal-updated">Última atualização: agosto de 2026.</p>
          {children}
        </article>
      </main>

      <footer className="site-footer legal-footer">
        <div className="container footer-inner">
          <Link className="brand brand-footer" href="/" aria-label="Voltar para a página inicial">
            <Image className="footer-logo" src="/logo-achadr.png" alt="Logotipo da achaDR" width={52} height={52} unoptimized />
            <span className="brand-copy"><strong>acha<span>DR</span></strong><small>Saúde no seu tempo, no seu preço.</small></span>
          </Link>
          <div className="footer-links">
            <Link href="/termos">Termos de Uso</Link>
            <Link href="/privacidade">Política de Privacidade</Link>
            <Link href="/#cadastro">Fazer cadastro</Link>
          </div>
        </div>
      </footer>
    </>
  );
}
