import type { CSSProperties, ReactNode } from "react";

/**
 * Ícones da landing — traço único, viewBox 24, `currentColor`.
 *
 * Mesma família e mesma assinatura do `Icone.tsx` do produto: uma marca não pode
 * ter dois desenhos de ícone. Os paths ficam aqui em vez de virem de uma
 * biblioteca porque o DESIGN_SYSTEM §7 pede reproduzir com a stack existente
 * antes de somar dependência — e são três ícones.
 *
 * Substituem os glifos ↗ ✓ + que estavam no lugar: glifo de texto muda de
 * desenho a cada sistema operacional, não herda espessura de traço e destoa do
 * resto da interface.
 */
const P: Record<string, ReactNode> = {
  check: <path d="m5 12.5 4.5 4.5L19 7" />,
  "arrow-up-right": (
    <>
      <path d="M7 17 17 7" />
      <path d="M8 7h9v9" />
    </>
  ),
  plus: (
    <>
      <path d="M12 5v14" />
      <path d="M5 12h14" />
    </>
  ),
};

export function Icone({
  nome,
  size = 18,
  className,
  style,
}: {
  nome: keyof typeof P | string;
  size?: number;
  className?: string;
  style?: CSSProperties;
}) {
  const d = P[nome];
  if (!d) return null;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      focusable="false"
      className={className}
      style={{ flexShrink: 0, ...style }}
    >
      {d}
    </svg>
  );
}
