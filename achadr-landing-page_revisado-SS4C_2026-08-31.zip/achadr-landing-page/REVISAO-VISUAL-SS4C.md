# Revisão visual — SS4C

A landing foi revisada para ficar consistente com **achadr.com.br**. O conteúdo, a
copy e a estrutura de seções foram preservados: o ajuste é de identidade visual.

## Como rodar

```bash
node -v            # precisa de 22.13 ou superior
npm run install:ci
npm run dev        # http://localhost:5173
npm run build      # verifica antes de publicar
```

## O que mudou, e por quê

| Item | Antes | Agora |
|---|---|---|
| **Fonte** | nenhuma carregada — o CSS pedia Inter e o navegador caía no fallback do sistema | Inter 400–800, o mesmo link do site |
| **Paleta** | navy `#071b3b`, creme, coral `#ff6f70`, teal `#20b9ad` | azul `#1565c0`, verde `#18c37e`, tinta `#0f172a` |
| **Fundo da página** | branco chapado | `#f5f7fa` com dois lavados fixos, azul e verde, a 10% |
| **Cabeçalho** | fixo, 82px, com desfoque e fundo escuro | transparente, 1120px, `18px 24px`, sem borda |
| **Marca** | "DR" em cor variável, logo 46px | "DR" em verde `#0e8f5b`, logo 42px raio 11 |
| **Botões** | pílula 52px, peso 760, salto no hover | raio 8, 46px, peso 500, sem sombra nem movimento |
| **Seções** | faixas opacas alternando claro e escuro | transparentes, com cartões brancos por cima |
| **Ícones** | glifos de texto `↗ ✓ +` | SVG próprio, viewBox 24, traço 1.75 |
| **Gradientes** | 28, a maioria brilho radial sobre fundo escuro | 6, todos lavados claros funcionais |

## Detalhes que valem atenção ao editar

- **Os tokens estão no topo de `app/globals.css`.** A segunda metade do `:root` é uma
  camada de compatibilidade: `--teal` aponta para o azul e `--coral` para o verde,
  porque a base usa esses nomes em muitos pontos. Ao mexer em cor, mexa no token.
- **O fundo é do `body`, não das seções.** Dar fundo a uma seção cria uma faixa que
  esconde o lavado e quebra a continuidade.
- **A variação por perfil muda só o acento.** Ela chegou repintando a página inteira
  em duas paletas — isso dá duas marcas ao mesmo produto.
- **Sem biblioteca de ícones.** `app/components/Icone.tsx` tem os paths; para um ícone
  novo, some ao mapa mantendo traço 1.75.

## Sugestão que não foi aplicada

Os cartões de benefício usam marcadores `01 / 02 / 03`, mas o conteúdo são três
propostas paralelas, não um processo — a numeração sugere uma ordem que não existe.
O visual dos três foi unificado (eram três cores distintas, e a terceira era branca,
invisível no cartão claro), mas os números ficaram: é decisão de conteúdo.

## Histórico

O repositório tem o estado original no primeiro commit, então dá para ver o diff
exato de cada mudança:

```bash
git log --oneline
git diff 7bf5f61 HEAD -- app/globals.css
```
