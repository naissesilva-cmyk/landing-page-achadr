CREATE TABLE `interest_leads` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`profile` text NOT NULL,
	`name` text NOT NULL,
	`contact` text NOT NULL,
	`city` text,
	`state` text,
	`specialty` text,
	`profession` text,
	`council_registration` text,
	`consent_at` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
