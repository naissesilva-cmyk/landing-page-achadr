import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { after, before, test } from "node:test";

const port = 42000 + (process.pid % 1000);
const baseUrl = `http://127.0.0.1:${port}`;
let server;
let serverOutput = "";

before(async () => {
  const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";
  server = spawn(
    npmCommand,
    ["run", "dev", "--", "--host", "127.0.0.1", "--port", String(port), "--strictPort"],
    {
      cwd: new URL("..", import.meta.url),
      detached: process.platform !== "win32",
      env: {
        ...process.env,
        MINIFLARE_REGISTRY_PATH: `/tmp/achadr-test-registry-${process.pid}`,
      },
      stdio: ["ignore", "pipe", "pipe"],
    },
  );

  const collect = (chunk) => {
    serverOutput = `${serverOutput}${chunk.toString()}`.slice(-12000);
  };
  server.stdout.on("data", collect);
  server.stderr.on("data", collect);

  const deadline = Date.now() + 20_000;
  while (Date.now() < deadline) {
    if (server.exitCode !== null) {
      throw new Error(`Development server exited early.\n${serverOutput}`);
    }

    try {
      const response = await fetch(baseUrl);
      if (response.ok) return;
    } catch {
      // The server is still starting.
    }

    await new Promise((resolve) => setTimeout(resolve, 150));
  }

  throw new Error(`Development server did not become ready.\n${serverOutput}`);
});

after(() => {
  if (!server || server.exitCode !== null) return;
  if (process.platform === "win32") server.kill("SIGTERM");
  else process.kill(-server.pid, "SIGTERM");
});

test("renders the achaDR pre-launch page and capture form", async () => {
  const response = await fetch(`${baseUrl}/`, {
    headers: { accept: "text/html" },
  });

  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
  const html = await response.text();
  assert.match(html, /achaDR/);
  assert.match(html, /Pré-lançamento para profissionais de saúde/i);
  assert.match(html, /Transforme horários disponíveis em novas consultas\./);
  assert.match(html, /Você decide quando e por quanto atender\./);
  assert.match(html, /Inscrição profissional gratuita/i);
  assert.match(html, /taxa de parceria.*reduzida pela metade/is);
  assert.match(html, /de 20% para 10%/i);
  assert.match(html, /Cadastrar como profissional/);
  assert.match(html, /Registre seus dados para garantir a isenção dos R\$ 50/);
  assert.match(html, /R\$ 50 por R\$ 0/);
  assert.match(html, /10% para sempre/);
  assert.match(html, /Use a achaDR junto às suas outras formas de atendimento/);
  assert.match(html, /Registro no conselho profissional/);
  assert.match(html, /CRM\/SP 123456, CRP 06\/123456 ou CRN-3 12345/);
  const councilInput = html.match(/<input[^>]+name="councilRegistration"[^>]*>/)?.[0] ?? "";
  assert.match(councilInput, /required/);
  assert.match(html, /RQE poderá ser solicitado na etapa de validação/);
  assert.doesNotMatch(html, /Como você quer usar a achaDR\?/);
  assert.doesNotMatch(html, /Cadastrar como paciente/);
  assert.doesNotMatch(html, /Planfamilia|case inicial|Asaas/i);
  assert.doesNotMatch(html, /Este cadastro libera acesso imediato\?/i);
  assert.match(html, /Política de Privacidade/);
  assert.match(html, /Termos de Uso/);
  assert.match(html, /logo-achadr\.png/);
  assert.match(html, /lang="pt-BR"/i);
  assert.doesNotMatch(html, /codex-preview/);
});

test("publishes the privacy policy and terms at their final paths", async () => {
  const privacyResponse = await fetch(`${baseUrl}/privacidade`);
  assert.equal(privacyResponse.status, 200);
  const privacyHtml = await privacyResponse.text();
  assert.match(privacyHtml, /Política de Privacidade/);
  assert.match(privacyHtml, /Direitos dos titulares/);
  assert.match(privacyHtml, /Cadastro antecipado profissional/);
  assert.match(privacyHtml, /registro no conselho profissional/);
  assert.doesNotMatch(privacyHtml, /Asaas/i);
  assert.doesNotMatch(privacyHtml, /realizar contato sobre disponibilidade/i);
  assert.doesNotMatch(privacyHtml, /codex-preview/);

  const termsResponse = await fetch(`${baseUrl}/termos`);
  assert.equal(termsResponse.status, 200);
  const termsHtml = await termsResponse.text();
  assert.match(termsHtml, /Termos de Uso/);
  assert.match(termsHtml, /A achaDR é uma plataforma de intermediação/);
  assert.match(termsHtml, /não gera obrigação de contato individual/i);
  assert.match(termsHtml, /taxa padrão da plataforma para o profissional será de 20%/i);
  assert.match(termsHtml, /taxa reduzida para 10% durante toda a permanência/i);
  assert.match(termsHtml, /processado pelo parceiro de pagamentos/i);
  assert.match(termsHtml, /Registro de Qualificação de Especialista \(RQE\)/);
  assert.doesNotMatch(termsHtml, /Planfamilia|case inicial|Asaas/i);
  assert.doesNotMatch(termsHtml, /codex-preview/);
});

test("validates capture requests before touching the database", async () => {
  const invalidResponse = await fetch(`${baseUrl}/api/interesse`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ profile: "profissional", consent: false }),
  });
  assert.equal(invalidResponse.status, 400);
  assert.deepEqual(await invalidResponse.json(), {
    error: "Informe seu nome e um contato válido.",
  });

  const patientResponse = await fetch(`${baseUrl}/api/interesse`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ profile: "paciente", name: "Pessoa", contact: "pessoa@example.com", consent: true }),
  });
  assert.equal(patientResponse.status, 400);
  assert.deepEqual(await patientResponse.json(), {
    error: "Este cadastro é exclusivo para profissionais de saúde.",
  });

  const missingCouncilResponse = await fetch(`${baseUrl}/api/interesse`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      profile: "profissional",
      name: "Profissional",
      contact: "profissional@example.com",
      profession: "Psicólogo",
      specialty: "Psicologia clínica",
      consent: true,
    }),
  });
  assert.equal(missingCouncilResponse.status, 400);
  assert.deepEqual(await missingCouncilResponse.json(), {
    error: "Informe seu registro no conselho profissional.",
  });

  const honeypotResponse = await fetch(`${baseUrl}/api/interesse`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ website: "bot.example" }),
  });
  assert.equal(honeypotResponse.status, 201);
  assert.deepEqual(await honeypotResponse.json(), { success: true });
});
